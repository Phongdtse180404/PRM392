package com.example.se180404_doanthanhphong_lab4;

public class FoodDrinkItem {
    public int hinh;
    public String ten;
    public String moTa;
    public String gia;

    public FoodDrinkItem(int hinh, String ten, String moTa, String gia) {
        this.hinh = hinh;
        this.ten = ten;
        this.moTa = moTa;
        this.gia = gia;
    }
}

